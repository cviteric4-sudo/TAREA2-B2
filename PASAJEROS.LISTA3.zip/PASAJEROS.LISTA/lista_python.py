# =====================================================================
#  lista_python.py  —  LISTA 2: con el list de PYTHON (built-in)
# ---------------------------------------------------------------------
#  Mismas operaciones que la Lista 1, pero ahora usamos lo que Python
#  ya trae: append, insert, pop, remove, sort, reverse, copy, len,
#  enumerate, next, bisect ... y LIST COMPREHENSIONS.
#
#      self.pasajeros -> [Pasajero, Pasajero, ...]   (crece sola)
#
#  ✅ OBLIGATORIO usar comprensiones de listas en (mínimo):
#       buscar · buscar_binaria · eliminar_por_valor (versión 2)
#       filtrar_mayores_de_edad · nombres_en_mayusculas
#
#  Recordatorio de la sintaxis:
#       [EXPRESIÓN for ELEMENTO in LISTA]            -> transformar
#       [ELEMENTO  for ELEMENTO in LISTA if COND]    -> filtrar
#       [EXPRESIÓN for ELEMENTO in LISTA if COND]    -> las dos a la vez
#
#  📌 Compara cada método con su gemelo de lista_manual.py:
#     allá eran 10 líneas, aquí casi siempre son 1 o 2.
#  Cuando termines un método, BORRA la línea "pass".
# =====================================================================

from bisect import bisect_left
from pasajero import Pasajero


class ListaPasajerosPython:

    def __init__(self):
        self.pasajeros = []               # list de Python: crece sola

    # -----------------------------------------------------------------
    # 1. AÑADIR  ✅ YA RESUELTO
    # -----------------------------------------------------------------
    def añadir(self, pasajero):
        """Añade al final con append()."""
        self.pasajeros.append(pasajero)
        return True
        # 🔧 MEJORA cuando termines buscar(): no añadir cédulas repetidas.

    # -----------------------------------------------------------------
    # 2. LISTAR  ✅ YA RESUELTO
    # -----------------------------------------------------------------
    def listar(self):
        """Muestra los pasajeros con su posición usando enumerate()."""
        if not self.pasajeros:                  # lista vacía es False
            print("(lista vacía)")
            return
        for i, p in enumerate(self.pasajeros):
            print(f"[{i}] {p}")

    # -----------------------------------------------------------------
    # 3. LONGITUD
    # -----------------------------------------------------------------
    def longitud(self):
        """
        USA      : len()
        RETORNA  : int.   PRUEBA: datos de prueba -> 5
        """
        pass

   # -----------------------------------------------------------------
    # 4. INSERTAR
    # -----------------------------------------------------------------
    def insertar(self, posicion, pasajero):
        """Inserta un pasajero en una posición válida."""
        if 0 <= posicion <= len(self.pasajeros):
            self.pasajeros.insert(posicion, pasajero)
            return True
        print("⚠ Posición no válida")
        return False

    # -----------------------------------------------------------------
    # 5. BUSCAR POR CÉDULA  (con COMPRENSIÓN)
    # -----------------------------------------------------------------
    def buscar(self, cedula):
        """Busca por cédula usando una comprensión con enumerate."""
        posiciones = [i for i, p in enumerate(self.pasajeros) if p.cedula == cedula]
        return posiciones[0] if posiciones else -1

    # -----------------------------------------------------------------
    # 6. BUSCAR BINARIA  (con COMPRENSIÓN + bisect)
    # -----------------------------------------------------------------
    def buscar_binaria(self, cedula):
        """Busca con búsqueda binaria sobre lista de cédulas."""
        cedulas = [p.cedula for p in self.pasajeros]
        i = bisect_left(cedulas, cedula)
        if i < len(cedulas) and cedulas[i] == cedula:
            return i
        return -1

    # -----------------------------------------------------------------
    # 7. MODIFICAR
    # -----------------------------------------------------------------
    def modificar(self, cedula, nuevo_nombre, nueva_edad):
        """Actualiza el nombre y edad según la cédula enviada."""
        pos = self.buscar(cedula)
        if pos == -1:
            print("⚠ Pasajero no encontrado")
            return False
        self.pasajeros[pos].nombre = nuevo_nombre
        self.pasajeros[pos].edad = nueva_edad
        return True

    # -----------------------------------------------------------------
    # 8. ELIMINAR POR POSICIÓN
    # -----------------------------------------------------------------
    def eliminar_por_posicion(self, posicion):
        """Quita y retorna el pasajero con pop()."""
        if 0 <= posicion < len(self.pasajeros):
            return self.pasajeros.pop(posicion)
        print("⚠ Posición fuera de rango")
        return None

    # -----------------------------------------------------------------
    # 9. ELIMINAR POR VALOR (por cédula)
    # -----------------------------------------------------------------
    def eliminar_por_valor(self, cedula):
        """
        FORMA 1 (comentada):
            pos = self.buscar(cedula)
            if pos != -1:
                return self.pasajeros.pop(pos) # o self.pasajeros.remove(...)
            return False
        """
        # FORMA 2 (comprensión de listas activa):
        antes = len(self.pasajeros)
        self.pasajeros = [p for p in self.pasajeros if p.cedula != cedula]
        return len(self.pasajeros) < antes

    # -----------------------------------------------------------------
    # 10. ORDENAR ASCENDENTE (por cédula)
    # -----------------------------------------------------------------
    def ordenar_asc(self):
        """Ordena en lugar por clave 'cedula'."""
        self.pasajeros.sort(key=lambda p: p.cedula)

    # -----------------------------------------------------------------
    # 11. ORDENAR DESCENDENTE (por cédula)
    # -----------------------------------------------------------------
    def ordenar_desc(self):
        """Ordena descendente por clave 'cedula'."""
        self.pasajeros.sort(key=lambda p: p.cedula, reverse=True)

    # -----------------------------------------------------------------
    # 12. REVERSAR
    # -----------------------------------------------------------------
    def reversar(self):
        """Invierte el orden con reverse()."""
        self.pasajeros.reverse()

    # -----------------------------------------------------------------
    # 13. COPIAR
    # -----------------------------------------------------------------
    def copiar(self):
        """Retorna una copia superficial de la estructura."""
        nueva = ListaPasajerosPython()
        nueva.pasajeros = self.pasajeros.copy()
        return nueva

    # -----------------------------------------------------------------
    # 14. FILTRAR MAYORES DE EDAD  (COMPRENSIÓN)
    # -----------------------------------------------------------------
    def filtrar_mayores_de_edad(self):
        """Retorna una nueva ListaPasajerosPython filtrada."""
        nueva = ListaPasajerosPython()
        nueva.pasajeros = [p for p in self.pasajeros if p.es_mayor_de_edad()]
        return nueva

    # -----------------------------------------------------------------
    # 15. NOMBRES EN MAYÚSCULAS  (COMPRENSIÓN)
    # -----------------------------------------------------------------
    def nombres_en_mayusculas(self):
        """Retorna una lista de strings con nombres transformados a mayúsculas."""
        return [p.nombre.upper() for p in self.pasajeros]